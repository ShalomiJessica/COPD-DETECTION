function [t,s]=zerocros(y,m,x)
%ZEROCROS finds the zeros crossings in a signal [T,S]=(Y,M,X)
% Inputs:  y = input waveform
%          m = mode string containing:
%              'p' - positive crossings only
%              'n' - negative crossings only
%              'b' - both (default)
%              'r' - round to sample values
%          x = x-axis values corresponding to y [default 1:length(y)]
%
% Outputs: t = x-axis positions of zero crossings
%          s = estimated slope of y at the zero crossing
%
% This routine uses linear interpolation to estimate the position of a zero crossing
% A zero crossing occurs between y(n) and y(n+1) iff (y(n)>=0) ~= (y(n+1)>=0)

% Example: y=sin(2*pi*(0:1000)/200); y(1:100:1001)=0; zerocros(y);
% Note that we get a zero crossing at the end but not at the start.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nargin<2 || ~numel(m)
    m='b';
end
s=y>=0;
k=s(2:end)-s(1:end-1);
if any(m=='p')
    f=find(k>0);
elseif any(m=='n')
    f=find(k<0);
else
    f=find(k~=0);
end
s=y(f+1)-y(f);
t=f-y(f)./s;
if any(m=='r')
    t=round(t);
end
if nargin>2
    tf=t-f; % fractional sample
    t=x(f).*(1-tf)+x(f+1).*tf;
    s=s./(x(f+1)-x(f));
end
if ~nargout
    n=length(y);
    plot(1:n,y,'-',t,zeros(length(t),1),'o');
end
