function rf=lpcis2rf(is)
%LPCRF2IS Convert inverse sines to reflection coefficients RF=(IS)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rf=sin(is*pi/2);
